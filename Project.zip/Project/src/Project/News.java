package Project;
import java.lang.*;
import java.util.*;

public class News extends Text {
    public News() {
        super();
    }

    public News(String NewsTitle, String NewsText) {
        super(NewsTitle, NewsText);
    }

    public News(String NewsTitle) {
        super(NewsTitle);
    }
}