package Project;

import java.io.Serializable;
import java.util.*;
/**
 */
public enum Degree implements Serializable {
    /**
     */
    BACHELOR, MASTER, PHD, DOCTOR;
}
