
import java.io.Serializable;
import java.util.*;
/**
 */
public enum Position implements Serializable {
    /**
     */
    TUTOR, LECTOR, SENIOR_LECTOR, PROFESSOR, ASSISTANT_PROFESSOR, ASSOCIATE_PROFESSOR;
}