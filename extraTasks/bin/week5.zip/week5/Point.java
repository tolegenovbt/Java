package week5;

public class Point {
	public int x;
	public int y;
	Point()
	{
		x=y=0;
	}
}
