package week5;
enum Color{
	Black, Red;
}

public abstract class AbstractShape {
	public Color color;
	abstract public void draw();

}