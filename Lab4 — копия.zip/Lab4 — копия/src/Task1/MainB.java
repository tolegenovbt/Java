package Task1;

public class MainB {
	public static void main(String[] args) {
		Files files = new Files();
		files.read("scores.txt");
		files.writeStats("grades.txt");	
	}
}