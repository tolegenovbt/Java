package Task1;

public class Main {
	static void main(String[] args)
	{
		
	}
}
